# Gemma Guard Core package
from .guard_service import call_gemma_guard
